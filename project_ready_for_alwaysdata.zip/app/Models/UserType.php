<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserType extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
    ];

    /**
     * Get all users that belong to this user type.
     */
    public function users()
    {
        return $this->hasMany(User::class);
    }
}
